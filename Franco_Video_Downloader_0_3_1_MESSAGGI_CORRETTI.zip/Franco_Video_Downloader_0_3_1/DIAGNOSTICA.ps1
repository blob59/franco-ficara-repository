# Diagnostica locale. Non trasmette informazioni su Internet.
$ErrorActionPreference = 'Continue'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$motor = Join-Path $base 'motore'
$dest = Join-Path $base 'diagnostica.txt'
$lines = New-Object System.Collections.Generic.List[string]
function Add-Line([string]$s) { Write-Host $s; [void]$lines.Add($s) }
Add-Line ('Franco Video Downloader 0.3 - diagnostica ' + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))
Add-Line ('Sistema: Windows PowerShell ' + $PSVersionTable.PSVersion.ToString())
Add-Line ('Windows: ' + [Environment]::OSVersion.VersionString)
$yt = Join-Path $motor 'yt-dlp.exe'
$deno = Join-Path $motor 'deno.exe'
$ff = Join-Path $motor 'ffmpeg.exe'
foreach ($entry in @(@('yt-dlp', $yt), @('Deno', $deno), @('FFmpeg', $ff))) {
  $name=$entry[0];$path=$entry[1]
  if(Test-Path -LiteralPath $path){
   Add-Line ($name + ': PRESENTE, dimensione ' + (Get-Item -LiteralPath $path).Length + ' byte')
   try{ $opt = if($name -eq 'FFmpeg'){'-version'}else{'--version'}; $ver = & $path $opt 2>&1 | Select-Object -First 1; Add-Line ('  Versione: ' + [string]$ver) } catch{ Add-Line ('  Errore eseguibile: ' + $_.Exception.Message) }
  } else {
   $onpath=Get-Command ($name -replace 'yt-dlp','yt-dlp.exe' -replace 'Deno','deno.exe' -replace 'FFmpeg','ffmpeg.exe') -ErrorAction SilentlyContinue
   if($null -ne $onpath){Add-Line ($name+': trovato nel PATH ('+$onpath.Source+')')}
   else{ Add-Line ($name+': MANCANTE. Usa INSTALLA_COMPONENTI.cmd.') }
  }
}
try {
 $resp = Invoke-WebRequest -Uri 'https://github.com/yt-dlp/yt-dlp/releases/latest' -UseBasicParsing -TimeoutSec 12 -Method Head
 Add-Line ('GitHub: raggiungibile (HTTP '+[int]$resp.StatusCode+')')
} catch{Add-Line ('GitHub: non raggiungibile o bloccato ('+$_.Exception.Message+')')}
try{
 $resp = Invoke-WebRequest -Uri 'https://www.youtube.com' -UseBasicParsing -TimeoutSec 12 -Method Head
 Add-Line ('YouTube: raggiungibile (HTTP '+[int]$resp.StatusCode+')')
}catch{Add-Line ('YouTube: accesso limitato o non raggiungibile ('+$_.Exception.Message+')')}
Add-Line 'NOTA: questo test non verifica la disponibilita di formati per un particolare video.'
try{ [System.IO.File]::WriteAllLines($dest, $lines.ToArray(), [System.Text.Encoding]::UTF8); Write-Host ('Rapporto salvato in: ' + $dest) -ForegroundColor Green }catch {Write-Host ('Impossibile salvare: '+$_.Exception.Message)}
