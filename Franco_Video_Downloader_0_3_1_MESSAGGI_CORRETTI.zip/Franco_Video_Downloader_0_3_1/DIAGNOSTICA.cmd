@echo off
setlocal
cd /d "%~dp0"
echo ====================================================
echo     FRANCO VIDEO DOWNLOADER - DIAGNOSTICA
 echo ====================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0DIAGNOSTICA.ps1"
echo.
echo Il risultato e' salvato anche in diagnostica.txt.
echo Se non scarica, inviami il testo di quel file evitando di includere link riservati.
pause
