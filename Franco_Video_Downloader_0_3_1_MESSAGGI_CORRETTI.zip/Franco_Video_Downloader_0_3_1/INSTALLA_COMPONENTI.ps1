# Franco Video Downloader 0.3 - installer esplicito su richiesta dell'utente.
# Origini verificate: yt-dlp, denoland/deno, gyan.dev.
$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$dest = Join-Path $base 'motore'
if (-not (Test-Path -LiteralPath $dest)) { New-Item -ItemType Directory -Path $dest -Force | Out-Null }
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$client = New-Object Net.WebClient
$client.Headers['User-Agent'] = 'Franco-Video-Downloader/0.3'
$tmp = Join-Path $env:TEMP ('franco-setup-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp | Out-Null
function Download-Verified([string]$url, [string]$sumUrl, [string]$outputName, [string]$label) {
    $file = Join-Path $tmp $outputName
    $sumPath = Join-Path $tmp ($outputName + '.sha256')
    Write-Host ('Scarico il checksum ufficiale: ' + $label) -ForegroundColor Cyan
    $client.DownloadFile($sumUrl, $sumPath)
    $txt = Get-Content -LiteralPath $sumPath -Raw
    $m = [regex]::Match($txt, '(?i)\b([a-f0-9]{64})\b')
    if (-not $m.Success) { throw ('Checksum SHA-256 non riconosciuto per ' + $label) }
    $expected = $m.Groups[1].Value.ToUpperInvariant()
    Write-Host ('Scarico ' + $label + ' dalla fonte ufficiale...') -ForegroundColor Cyan
    $client.DownloadFile($url, $file)
    $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToUpperInvariant()
    if ($expected -ne $actual) { throw ('Verifica di integrita fallita per ' + $label + '. File NON installato.') }
    Write-Host ('SHA-256 verificato: ' + $label) -ForegroundColor Green
    return $file
}
function Put-Exe([string]$inputPath, [string]$name) {
    $target = Join-Path $dest $name
    if (Test-Path -LiteralPath $target) { Remove-Item -LiteralPath $target -Force }
    Move-Item -LiteralPath $inputPath -Destination $target -Force
}
$failed = @()
try {
    try {
        $url = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe'
        $sum = 'https://github.com/yt-dlp/yt-dlp/releases/latest/download/SHA2-256SUMS'
        # La lista contiene piu file: selezioniamo la riga esatta di yt-dlp.exe.
        $sumPath = Join-Path $tmp 'SHA2-256SUMS'
        Write-Host 'Scarico e verifico yt-dlp...' -ForegroundColor Cyan
        $client.DownloadFile($sum, $sumPath)
        $manifest = Get-Content -LiteralPath $sumPath -Raw
        $m = [regex]::Match($manifest, '(?im)^([a-f0-9]{64})\s+\*?yt-dlp\.exe\s*$')
        if (-not $m.Success) { throw 'Checksum di yt-dlp.exe non trovato nella lista ufficiale.' }
        $file = Join-Path $tmp 'yt-dlp.exe'
        $client.DownloadFile($url, $file)
        if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash -ne $m.Groups[1].Value.ToUpperInvariant()) { throw 'SHA-256 yt-dlp non corrisponde.' }
        Put-Exe $file 'yt-dlp.exe'
        Write-Host 'yt-dlp verificato e installato.' -ForegroundColor Green
    } catch {
        $failed += 'yt-dlp'
        Write-Host ('ERRORE yt-dlp: ' + $_.Exception.Message) -ForegroundColor Red
    }
    try {
        $denoUrl = 'https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip'
        $denoZip = Download-Verified $denoUrl ($denoUrl + '.sha256sum') 'deno.zip' 'Deno Windows'
        $folder = Join-Path $tmp 'denoExtract'
        Expand-Archive -LiteralPath $denoZip -DestinationPath $folder -Force
        $denoExe = Get-ChildItem -LiteralPath $folder -Filter deno.exe -Recurse -File | Select-Object -First 1
        if ($null -eq $denoExe) { throw 'deno.exe non trovato nell archivio ufficiale.' }
        Put-Exe $denoExe.FullName 'deno.exe'
        Write-Host 'Deno verificato e installato.' -ForegroundColor Green
    } catch {
        $failed += 'Deno'
        Write-Host ('ERRORE Deno: ' + $_.Exception.Message) -ForegroundColor Red
    }
    try {
        $ff = Get-Command ffmpeg.exe -ErrorAction SilentlyContinue
        if ($null -ne $ff) {
            Write-Host ('FFmpeg gia disponibile nel PATH: ' + $ff.Source) -ForegroundColor Green
        } elseif (Test-Path -LiteralPath (Join-Path $dest 'ffmpeg.exe')) {
            Write-Host 'FFmpeg gia disponibile nella cartella motore.' -ForegroundColor Green
        } else {
            $ffUrl = 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip'
            $ffZip = Download-Verified $ffUrl ($ffUrl + '.sha256') 'ffmpeg.zip' 'FFmpeg Essentials'
            $ffFolder = Join-Path $tmp 'ffmpegExtract'
            Write-Host 'Estraggo FFmpeg (archivio grande)...' -ForegroundColor Cyan
            Expand-Archive -LiteralPath $ffZip -DestinationPath $ffFolder -Force
            $ffExe = Get-ChildItem -LiteralPath $ffFolder -Filter ffmpeg.exe -Recurse -File | Select-Object -First 1
            if ($null -eq $ffExe) { throw 'ffmpeg.exe non trovato nel pacchetto.' }
            Put-Exe $ffExe.FullName 'ffmpeg.exe'
            Write-Host 'FFmpeg verificato e installato.' -ForegroundColor Green
        }
    } catch {
        $failed += 'FFmpeg'
        Write-Host ('ERRORE FFmpeg: ' + $_.Exception.Message) -ForegroundColor Red
    }
} finally {
    $client.Dispose()
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
if ($failed.Count -gt 0) {
    Write-Host ('MANCANO: ' + ($failed -join ', ')) -ForegroundColor Yellow
    Write-Host 'Esegui DIAGNOSTICA.cmd per controllare i componenti e copiare gli errori.' -ForegroundColor Yellow
    exit 1
}
Write-Host 'INSTALLAZIONE COMPLETATA. Puoi aprire Franco Video Downloader.' -ForegroundColor Green
exit 0
