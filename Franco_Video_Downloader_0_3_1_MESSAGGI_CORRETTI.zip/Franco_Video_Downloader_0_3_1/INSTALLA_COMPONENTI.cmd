@echo off
setlocal
cd /d "%~dp0"
echo ====================================================
echo       FRANCO VIDEO DOWNLOADER - COMPONENTI
 echo ====================================================
echo Il programma scarica motori gratuiti e li verifica con SHA-256.
echo Origini: yt-dlp, Deno, FFmpeg (compilazione Gyan).
echo I componenti saranno salvati solo nella cartella motore.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLA_COMPONENTI.ps1"
set "RESULT=%errorlevel%"
echo.
if "%RESULT%"=="0" (echo COMPONENTI INSTALLATI. Torna al programma e premi Diagnostica.) else (echo INSTALLAZIONE NON COMPLETATA. Guarda l'errore qui sopra.)
pause
exit /b %RESULT%
