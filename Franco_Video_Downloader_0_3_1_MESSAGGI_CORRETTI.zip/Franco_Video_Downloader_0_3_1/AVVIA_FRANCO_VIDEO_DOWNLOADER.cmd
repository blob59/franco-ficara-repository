@echo off
setlocal
cd /d "%~dp0"
echo Avvio Franco Video Downloader 0.3.1...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Franco_Video_Downloader.ps1"
if errorlevel 1 (
 echo.
 echo Il programma non si e' avviato correttamente.
 echo Esegui DIAGNOSTICA.cmd e inviami il risultato se hai bisogno di assistenza.
 pause
)
