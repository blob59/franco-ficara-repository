# Franco Video Downloader 0.3.1 - Franco Ficara Digital Studio
# Front-end gratuito Windows per yt-dlp. Non aggira DRM, scarica solo contenuti autorizzati.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:base = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:motor = Join-Path $script:base 'motore'
$script:engine = Join-Path $script:motor 'yt-dlp.exe'
$script:deno = Join-Path $script:motor 'deno.exe'
$script:ffmpeg = Join-Path $script:motor 'ffmpeg.exe'
$script:session = Join-Path $script:base 'logs'
if(-not (Test-Path -LiteralPath $script:session)){New-Item -ItemType Directory -Path $script:session -Force | Out-Null}
$script:process = $null
$script:outLog = ''
$script:errLog = ''
$script:lastText = ''
$script:prevProgress = ''
$script:filename = ''
$script:busy = $false
$script:serial = 0
$form = New-Object System.Windows.Forms.Form
$form.Text='Franco Video Downloader 0.3.1 BETA - Franco Ficara Digital Studio'
$form.Width=840;$form.Height=750
$form.MinimumSize=New-Object System.Drawing.Size(810,690)
$form.StartPosition='CenterScreen'
$form.BackColor=[System.Drawing.Color]::FromArgb(19,28,42)
$form.ForeColor=[System.Drawing.Color]::White
$form.Font=New-Object System.Drawing.Font('Segoe UI',10)

function Make-Label([string]$s,[int]$x,[int]$y,[int]$w,[int]$h,[int]$size=10){
 $l=New-Object System.Windows.Forms.Label
 $l.Location=New-Object System.Drawing.Point($x,$y)
 $l.Size=New-Object System.Drawing.Size($w,$h)
 $l.Text=$s
 $l.Font=New-Object System.Drawing.Font('Segoe UI',$size)
 $l.ForeColor=[System.Drawing.Color]::FromArgb(235,232,241)
 $form.Controls.Add($l)
 return $l
}
function Make-Button([string]$s,[int]$x,[int]$y,[int]$w,[int]$h=38){
 $b=New-Object System.Windows.Forms.Button
 $b.Location=New-Object System.Drawing.Point($x,$y)
 $b.Size=New-Object System.Drawing.Size($w,$h)
 $b.Text=$s;$b.FlatStyle='Flat';$b.FlatAppearance.BorderSize=0
 $b.BackColor=[System.Drawing.Color]::FromArgb(63,112,135)
 $b.ForeColor=[System.Drawing.Color]::White
 $form.Controls.Add($b)
 return $b
}
$mark=Make-Label 'FF' 27 18 55 57 22
$mark.TextAlign='MiddleCenter'
$mark.BorderStyle='FixedSingle'
$mark.BackColor=[System.Drawing.Color]::FromArgb(30,72,88)
$mark.ForeColor=[System.Drawing.Color]::FromArgb(146,221,215)
$mark.Font=New-Object System.Drawing.Font('Segoe UI',22,[System.Drawing.FontStyle]::Bold)
$title=Make-Label 'FRANCO VIDEO DOWNLOADER' 97 19 675 40 19
$title.Font=New-Object System.Drawing.Font('Segoe UI',19,[System.Drawing.FontStyle]::Bold)
$title.ForeColor=[System.Drawing.Color]::FromArgb(146,221,215)
$subtitle=Make-Label 'BETA 0.3.1  |  FRANCO FICARA DIGITAL STUDIO  |  WINDOWS 10/11' 98 61 680 24 10
$notice=Make-Label 'Solo video con permesso o autorizzazione. Un video pubblicamente visibile non e automaticamente scaricabile: rispetta le condizioni della piattaforma e la legge.' 26 94 755 48 9
$notice.ForeColor=[System.Drawing.Color]::FromArgb(255,216,168)
$lbl1=Make-Label '1. Incolla il link del video YouTube' 26 150 710 24 10
$urlInput=New-Object System.Windows.Forms.TextBox
$urlInput.Location=New-Object System.Drawing.Point(26,180)
$urlInput.Size=New-Object System.Drawing.Size(750,28)
$urlInput.Anchor='Top,Left,Right'
$form.Controls.Add($urlInput)
$lbl2=Make-Label '2. Cartella in cui salvare i file' 26 225 650 24 10
$folderInput=New-Object System.Windows.Forms.TextBox
$folderInput.Location=New-Object System.Drawing.Point(26,255)
$folderInput.Size=New-Object System.Drawing.Size(602,28)
$folderInput.Anchor='Top,Left,Right'
$downloadFolder=[Environment]::GetFolderPath('MyVideos')
if([string]::IsNullOrEmpty($downloadFolder)){ $downloadFolder=Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Videos' }
$folderInput.Text=$downloadFolder
$form.Controls.Add($folderInput)
$browse=Make-Button 'Sfoglia...' 650 249 125
$browse.Anchor='Top,Right'
$lbl3=Make-Label '3. Qualita e formato di uscita' 26 299 720 23 10
$format=New-Object System.Windows.Forms.ComboBox
$format.Location=New-Object System.Drawing.Point(26,327)
$format.Size=New-Object System.Drawing.Size(749,31)
$format.DropDownStyle='DropDownList'
[void]$format.Items.Add('Video MP4 alta qualita (richiede FFmpeg)')
[void]$format.Items.Add('Video file singolo con audio, quando disponibile')
[void]$format.Items.Add('Solo audio MP3 (richiede FFmpeg)')
$format.SelectedIndex=0;$format.Anchor='Top,Left,Right'
$form.Controls.Add($format)
$rights=New-Object System.Windows.Forms.CheckBox
$rights.Location=New-Object System.Drawing.Point(26,370)
$rights.Size=New-Object System.Drawing.Size(753,33)
$rights.Text='Confermo di avere diritto o permesso a scaricare il contenuto.'
$rights.ForeColor=[System.Drawing.Color]::FromArgb(244,218,181)
$form.Controls.Add($rights)
$prepare=Make-Button 'Prepara componenti' 26 416 189
$diagnostics=Make-Button 'Diagnostica' 227 416 124
$start=Make-Button 'Scarica' 362 416 136
$start.BackColor=[System.Drawing.Color]::FromArgb(26,131,117)
$openFolder=Make-Button 'Apri cartella' 509 416 130
$copyLog=Make-Button 'Copia registro' 650 416 126
$progress=Make-Label 'Controllo componenti...' 26 467 750 30 10
$progress.ForeColor=[System.Drawing.Color]::FromArgb(152,223,193)
$logBox=New-Object System.Windows.Forms.TextBox
$logBox.Location=New-Object System.Drawing.Point(26,504)
$logBox.Size=New-Object System.Drawing.Size(749,129)
$logBox.Multiline=$true;$logBox.ReadOnly=$true;$logBox.ScrollBars='Vertical'
$logBox.BackColor=[System.Drawing.Color]::FromArgb(9,16,25)
$logBox.ForeColor=[System.Drawing.Color]::FromArgb(214,233,225)
$logBox.Anchor='Top,Bottom,Left,Right'
$form.Controls.Add($logBox)
$link=New-Object System.Windows.Forms.LinkLabel
$link.Location=New-Object System.Drawing.Point(26,653)
$link.Size=New-Object System.Drawing.Size(730,28)
$link.Anchor='Bottom,Left,Right'
$link.Text='FRANCO FICARA REPOSITORY  |  Programmi gratuiti, guide e aggiornamenti'
$link.LinkColor=[System.Drawing.Color]::FromArgb(145,227,223)
$form.Controls.Add($link)
function Log([string]$s){
 if([string]::IsNullOrWhiteSpace($s)){return}
 if($logBox.TextLength -gt 25000){$logBox.Text=$logBox.Text.Substring($logBox.TextLength - 16000)}
 $logBox.AppendText($s+[Environment]::NewLine)
}
function Status([string]$s){$progress.Text=$s;Log $s}
function Has([string]$path){return Test-Path -LiteralPath $path -PathType Leaf}
function Has-FFmpeg(){if(Has $script:ffmpeg){return $true};return ($null -ne (Get-Command ffmpeg.exe -ErrorAction SilentlyContinue))}
function Get-JSArg(){
 if(Has $script:deno){return ('deno:'+$script:deno)}
 $denoSystem=Get-Command deno.exe -ErrorAction SilentlyContinue
 if($null -ne $denoSystem){return 'deno'}
 $nodeSystem=Get-Command node.exe -ErrorAction SilentlyContinue
 if($null -ne $nodeSystem){
   try{$ver = (& $nodeSystem.Source --version).TrimStart('v');if([version]$ver -ge [version]'22.0.0'){return 'node'}}catch{}
 }
 return ''
}
function Get-Ready(){return (Has $script:engine)}
function Refresh-Buttons(){
 $busy=$script:busy
 $start.Enabled=(-not $busy -and (Get-Ready))
 $prepare.Enabled=(-not $busy)
 $browse.Enabled=(-not $busy)
 $rights.Enabled=(-not $busy)
 $format.Enabled=(-not $busy)
 $urlInput.Enabled=(-not $busy)
 $folderInput.Enabled=(-not $busy)
}
function Validate-URL([string]$s){
 if($s.Length -gt 2048 -or $s.Length -lt 12){return $false}
 try{
  $u = New-Object System.Uri($s)
  return ($u.Scheme -eq 'https' -and ($u.Host -eq 'youtu.be' -or $u.Host -eq 'youtube.com' -or $u.Host.EndsWith('.youtube.com')))
 }catch{return $false}
}
function Quote-Arg([string]$s){return ('"'+$s.Replace('"','')+'"')}
$browse.Add_Click({
 $d=New-Object System.Windows.Forms.FolderBrowserDialog
 if(Test-Path -LiteralPath $folderInput.Text){$d.SelectedPath=$folderInput.Text}
 if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){$folderInput.Text=$d.SelectedPath}
 $d.Dispose()
})
$openFolder.Add_Click({
 if(Test-Path -LiteralPath $folderInput.Text -PathType Container){Start-Process explorer.exe -ArgumentList (Quote-Arg $folderInput.Text)}
 else{[System.Windows.Forms.MessageBox]::Show('La cartella scelta non esiste.','Percorso') | Out-Null}
})
$copyLog.Add_Click({
 try{[System.Windows.Forms.Clipboard]::SetText($logBox.Text);Status 'Registro copiato negli appunti.'}
 catch{Status ('Impossibile copiare: '+$_.Exception.Message)}
})
$link.Add_LinkClicked({Start-Process 'https://blob59.github.io/franco-ficara-repository/'})
$prepare.Add_Click({
 try{
  $installer=Join-Path $script:base 'INSTALLA_COMPONENTI.cmd'
  Start-Process -FilePath $installer -WorkingDirectory $script:base
  Status 'Si e aperta la finestra di installazione. Segui i messaggi fino al risultato.'
 }catch{Status ('Installazione non avviata: '+$_.Exception.Message)}
})
$diagnostics.Add_Click({
 $js = Get-JSArg
 Log ('Motore yt-dlp: '+$(if(Get-Ready){'PRESENTE'}else{'MANCANTE'}))
 Log ('Runtime JS: '+$(if($js){$js}else{'MANCANTE - premi Prepara componenti'}))
 Log ('FFmpeg: '+$(if(Has-FFmpeg){'PRESENTE'}else{'MANCANTE - necessario per MP4 alta qualita e MP3'}))
 try{Start-Process -FilePath (Join-Path $script:base 'DIAGNOSTICA.cmd') -WorkingDirectory $script:base;Status 'Finestra diagnostica aperta. Salvera diagnostica.txt.'}
 catch{Status ('Impossibile avviare diagnostica: '+$_.Exception.Message)}
})
$start.Add_Click({
 if($script:busy){return}
 if(-not $rights.Checked){Status 'Prima conferma il diritto di scaricare il video.';return}
 if(-not (Get-Ready)){Status 'Motore mancante. Premi Prepara componenti.';return}
 $url=$urlInput.Text.Trim()
 if(-not (Validate-URL $url)){Status 'Inserisci un collegamento https valido di youtube.com o youtu.be.';return}
 $dest=$folderInput.Text.Trim()
 if(-not (Test-Path -LiteralPath $dest -PathType Container)){Status 'La cartella di destinazione non esiste. Usa Sfoglia.';return}
 $runtime=Get-JSArg
 if(-not $runtime){Status 'Runtime JavaScript non trovato. Premi Prepara componenti per installare Deno.';return}
 if(($format.SelectedIndex -eq 0 -or $format.SelectedIndex -eq 2) -and -not (Has-FFmpeg)){
  Status 'FFmpeg non trovato. Premi Prepara componenti oppure scegli il formato file singolo.';return
 }
 $script:serial += 1
 $stamp=Get-Date -Format 'yyyyMMdd_HHmmss'
 $script:outLog=Join-Path $script:session ('yt-out-'+$stamp+'-'+$script:serial+'.txt')
 $script:errLog=Join-Path $script:session ('yt-err-'+$stamp+'-'+$script:serial+'.txt')
 $args='--ignore-config --no-playlist --no-overwrites --windows-filenames --newline '
 $args+='--js-runtimes '+(Quote-Arg $runtime)+' --remote-components ejs:github '
 $args+='-P '+(Quote-Arg $dest)+' -o '+(Quote-Arg '%(title).100B [%(id)s].%(ext)s')+' '
 if(Has $script:ffmpeg){$args+='--ffmpeg-location '+(Quote-Arg $script:motor)+' '}
 if($format.SelectedIndex -eq 0){$args+='-f '+(Quote-Arg 'bv*+ba/b')+' --merge-output-format mp4 '}
 elseif($format.SelectedIndex -eq 1){$args+='-f '+(Quote-Arg 'b[ext=mp4]/b')+' '}
 else{$args+='-f '+(Quote-Arg 'ba/b')+' -x --audio-format mp3 '}
 $args+=Quote-Arg $url
 try{
  $logBox.Clear()
  $script:process=Start-Process -FilePath $script:engine -ArgumentList $args -WorkingDirectory $script:base -WindowStyle Hidden -RedirectStandardOutput $script:outLog -RedirectStandardError $script:errLog -PassThru
  $script:busy=$true;$script:prevProgress=''
  Status ('Download avviato. Registri: '+$script:session)
 }catch{
  $script:busy=$false;$script:process=$null
  Status ('Errore di avvio: '+$_.Exception.Message)
 }
 Refresh-Buttons
})
$timer=New-Object System.Windows.Forms.Timer
$timer.Interval=750
$timer.Add_Tick({
 if(-not $script:busy -or $null -eq $script:process){Refresh-Buttons;return}
 if(Test-Path -LiteralPath $script:outLog){
  try{$txt=(@(Get-Content -LiteralPath $script:outLog -Tail 2 -ErrorAction SilentlyContinue) -join ' | ').Trim();if($txt -and $txt -ne $script:prevProgress){$script:prevProgress=$txt;$progress.Text=$txt}}
  catch{}
 }
  if($script:process.HasExited){
   # WaitForExit assicura che il codice di uscita e i log siano disponibili.
   # $null e diverso da 0: non mostrare un errore con un codice vuoto.
   $rc=$null
   try{$script:process.WaitForExit();$rc=$script:process.ExitCode}catch{}
   $outText='';$errText=''
   if(Test-Path -LiteralPath $script:outLog){
    try{$outText=Get-Content -LiteralPath $script:outLog -Raw -ErrorAction Stop}catch{}
   }
   if(Test-Path -LiteralPath $script:errLog){
    try{$errText=Get-Content -LiteralPath $script:errLog -Raw -ErrorAction Stop}catch{}
   }
   foreach($file in @($script:outLog,$script:errLog)){
    if(Test-Path -LiteralPath $file){Get-Content -LiteralPath $file -Tail 18 -ErrorAction SilentlyContinue | ForEach-Object {Log ([string]$_)}}
   }
   $alreadyPresent=($outText -match 'has already been downloaded')
   $hasEngineError=(($outText -match '(?im)^\s*ERROR:') -or ($errText -match '(?im)^\s*ERROR:'))
   $script:process.Dispose();$script:process=$null;$script:busy=$false
   if($hasEngineError -or ($null -ne $rc -and $rc -ne 0)){
    $codeLabel=if($null -eq $rc){'non disponibile'}else{[string]$rc}
    Status ('Download non riuscito (codice '+$codeLabel+'). Leggi il registro e usa Copia registro per assistenza.')
   }
   elseif($alreadyPresent){
    Status 'File gia presente nella cartella Video scelta: non e stato scaricato di nuovo. Premi Apri cartella.'
   }
   elseif($null -ne $rc -and $rc -eq 0){
    Status 'Download completato correttamente. Premi Apri cartella per vedere il file.'
   }
   else{
    Status 'Operazione terminata, ma non e stato possibile verificare l esito. Premi Apri cartella e controlla il registro.'
   }
   Refresh-Buttons
  }
})
$timer.Start()
if(Get-Ready){Status 'Motore trovato. Premi Diagnostica per verificare anche Deno e FFmpeg.'}
else{Status 'Motore non installato: premi Prepara componenti.'}
Refresh-Buttons
try{[void][System.Windows.Forms.Application]::Run($form)}
finally{$timer.Stop();$timer.Dispose()}
