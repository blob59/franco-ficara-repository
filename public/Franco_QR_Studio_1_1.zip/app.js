/* Franco QR Studio — Franco Ficara Digital Studio. Versione pubblica statica: nessun upload/server/storage. */
(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const types = [
    {id:'web',icon:'↗',name:'Sito web / Link',desc:'Apri un sito, una pagina o un contenuto online',tip:'Inserisci un indirizzo completo, ad esempio https://francoficara.com.'},
    {id:'text',icon:'≡',name:'Testo libero',desc:'Mostra una frase, un messaggio o delle istruzioni',tip:'Il testo viene inserito direttamente nel QR. Testi molto lunghi creano codici più difficili da leggere.'},
    {id:'email',icon:'✉',name:'Email',desc:'Apri una nuova email con destinatario e messaggio',tip:'Alla scansione si apre l’app di posta, con destinatario, oggetto e messaggio già compilati.'},
    {id:'photo',icon:'▣',name:'Foto / Immagine',desc:'Fai aprire una fotografia pubblicata online',tip:'Il QR contiene il link alla foto, non la fotografia. La foto deve essere raggiungibile tramite un link pubblico HTTPS.'},
    {id:'pdf',icon:'▤',name:'PDF / Documento',desc:'Condividi un documento tramite un collegamento',tip:'Carica prima il PDF su uno spazio accessibile tramite link e incolla qui l’indirizzo pubblico.'},
    {id:'wifi',icon:'◉',name:'Rete Wi-Fi',desc:'Collega uno smartphone a una rete Wi-Fi',tip:'La maggior parte degli smartphone può proporre la connessione Wi-Fi dopo la scansione. Non pubblicare il codice di una rete privata senza permesso.'},
    {id:'contact',icon:'♙',name:'Biglietto da visita',desc:'Aggiungi un contatto alla rubrica (vCard)',tip:'Nome e almeno un recapito; il telefono può proporre il salvataggio in rubrica.'},
    {id:'phone',icon:'☎',name:'Telefono',desc:'Avvia una chiamata al numero selezionato',tip:'Il telefono chiede conferma prima di effettuare una chiamata.'},
    {id:'sms',icon:'▧',name:'SMS',desc:'Prepara un messaggio SMS già compilato',tip:'La lettura apre un’app SMS compatibile senza inviare il messaggio automaticamente.'},
    {id:'whatsapp',icon:'◌',name:'WhatsApp',desc:'Apri una chat WhatsApp con testo facoltativo',tip:'Inserisci il numero completo di prefisso internazionale, senza +, spazi o zeri aggiuntivi.'},
    {id:'event',icon:'▦',name:'Evento',desc:'Apri un evento precompilato su Google Calendar',tip:'Si apre un link di Google Calendar con titolo, date e dettagli: serve una connessione Internet.'},
    {id:'location',icon:'⌖',name:'Posizione / Mappa',desc:'Apri un luogo su Google Maps',tip:'Inserisci un indirizzo o il nome di un luogo; il QR lo cercherà su Google Maps.'},
    {id:'video',icon:'▷',name:'Video / YouTube',desc:'Apri un video pubblicato online',tip:'Usa il link pubblico del video, non il percorso di un file sul tuo computer.'},
    {id:'social',icon:'♧',name:'Social media',desc:'Condividi un profilo o una pagina social',tip:'Funziona con Instagram, Facebook, TikTok, LinkedIn e altre piattaforme tramite URL.'},
  ];
  const fields = {
    web: `<div class="field"><label for="url">Indirizzo del sito *</label><input id="url" name="url" type="url" placeholder="https://www.esempio.it" value="https://francoficara.com" autocomplete="url" required><div class="help-text">Il collegamento si aprirà nel browser del telefono.</div></div>`,
    text: `<div class="field"><label for="message">Testo da mostrare *</label><textarea id="message" name="message" placeholder="Scrivi qui il tuo messaggio..." maxlength="2200" required></textarea><div class="help-text">Consigliato: fino a poche centinaia di caratteri, per una lettura più rapida.</div></div>`,
    email: `<div class="field"><label for="to">Email del destinatario *</label><input id="to" name="to" type="email" placeholder="nome@esempio.it" required></div><div class="field"><label for="subject">Oggetto</label><input id="subject" name="subject" placeholder="Richiesta informazioni"></div><div class="field"><label for="body">Messaggio</label><textarea id="body" name="body" placeholder="Buongiorno, vorrei..." maxlength="1600"></textarea></div>`,
    photo: `<div class="static-link-card"><span class="static-link-icon">▣</span><div><strong>Hai una fotografia già online?</strong><p>Incolla il suo collegamento pubblico. Il QR aprirà la foto (o la pagina che la mostra) sul telefono di chi lo scansiona.</p></div></div><div class="field"><label for="photoUrl">Link pubblico alla fotografia *</label><input id="photoUrl" name="photoUrl" type="url" placeholder="https://www.esempio.it/fotografia.jpg" autocomplete="url" required><div class="help-text">La foto deve essere già su un sito o servizio di condivisione accessibile a chi possiede il link.</div></div><div class="link-actions"><button class="verify-link" type="button" data-link-field="photoUrl">↗ Prova ad aprire il link</button></div><details class="why-link"><summary>Perché il QR richiede un link per aprire la foto da altri telefoni?</summary><p>Il QR contiene un indirizzo, non la fotografia. Per permettere agli altri di vederla, devi prima pubblicarla su un servizio a tua scelta e usare il link condivisibile. Franco QR Studio non riceve né conserva le foto.</p></details>`,
    pdf: `<div class="static-link-card"><span class="static-link-icon">▤</span><div><strong>Hai un PDF o documento già online?</strong><p>Incolla il collegamento pubblico. Chi scansisce il QR potrà aprire il documento, secondo le autorizzazioni del servizio che lo ospita.</p></div></div><div class="field"><label for="pdfUrl">Link pubblico al documento *</label><input id="pdfUrl" name="pdfUrl" type="url" placeholder="https://www.esempio.it/documento.pdf" autocomplete="url" required><div class="help-text">Può essere anche un link di condivisione: verifica che sia accessibile senza accedere al tuo account.</div></div><div class="link-actions"><button class="verify-link" type="button" data-link-field="pdfUrl">↗ Prova ad aprire il link</button></div><details class="why-link"><summary>Perché non posso caricare il PDF direttamente?</summary><p>Per mantenere il servizio gratuito senza archiviare i file delle persone, Franco QR Studio genera soltanto il QR dell'indirizzo pubblico. Se il file originale viene rimosso o reso privato, il QR non riuscirà più ad aprirlo.</p></details>`,
    wifi: `<div class="field"><label for="ssid">Nome della rete (SSID) *</label><input id="ssid" name="ssid" placeholder="WiFi di casa" required></div><div class="field-grid"><div class="field"><label for="security">Tipo di sicurezza</label><select id="security" name="security"><option value="WPA">WPA / WPA2 / WPA3</option><option value="WEP">WEP</option><option value="nopass">Rete aperta</option></select></div><div class="field"><label for="password">Password</label><input id="password" name="password" type="text" placeholder="Password Wi-Fi"></div></div><label class="checkline"><input type="checkbox" id="hidden" name="hidden"> Rete nascosta</label>`,
    contact: `<div class="field-grid"><div class="field"><label for="first">Nome *</label><input id="first" name="first" placeholder="Franco" required></div><div class="field"><label for="last">Cognome</label><input id="last" name="last" placeholder="Ficara"></div></div><div class="field"><label for="org">Azienda / Organizzazione</label><input id="org" name="org" placeholder="Franco Ficara Digital Studio"></div><div class="field"><label for="contactTel">Telefono</label><input id="contactTel" name="contactTel" type="tel" placeholder="+39 ..."></div><div class="field"><label for="contactMail">Email</label><input id="contactMail" name="contactMail" type="email" placeholder="nome@dominio.it"></div><div class="field"><label for="contactWeb">Sito web</label><input id="contactWeb" name="contactWeb" placeholder="https://..."></div>`,
    phone: `<div class="field"><label for="phone">Numero telefonico *</label><input id="phone" name="phone" type="tel" placeholder="+39 333 1234567" required></div>`,
    sms: `<div class="field"><label for="smsTo">Numero destinatario *</label><input id="smsTo" name="smsTo" type="tel" placeholder="+39 333 1234567" required></div><div class="field"><label for="smsBody">Testo SMS</label><textarea id="smsBody" name="smsBody" maxlength="1000" placeholder="Ciao, ti scrivo per..."></textarea></div>`,
    whatsapp: `<div class="field"><label for="waTo">Numero WhatsApp con prefisso internazionale *</label><input id="waTo" name="waTo" type="tel" placeholder="393331234567" required></div><div class="field"><label for="waText">Messaggio iniziale</label><textarea id="waText" name="waText" maxlength="1200" placeholder="Ciao, vorrei informazioni..."></textarea></div>`,
    event: `<div class="field"><label for="eventName">Titolo evento *</label><input id="eventName" name="eventName" placeholder="Presentazione del libro" required></div><div class="field-grid"><div class="field"><label for="start">Inizio *</label><input type="datetime-local" id="start" name="start" required></div><div class="field"><label for="end">Fine *</label><input type="datetime-local" id="end" name="end" required></div></div><div class="field"><label for="eventPlace">Luogo</label><input id="eventPlace" name="eventPlace" placeholder="Biblioteca comunale"></div><div class="field"><label for="details">Descrizione</label><textarea id="details" name="details" maxlength="900" placeholder="Dettagli dell'evento..."></textarea></div>`,
    location: `<div class="field"><label for="place">Indirizzo o luogo *</label><input id="place" name="place" placeholder="Brancaleone, Reggio Calabria" required></div>`,
    video: `<div class="field"><label for="videoUrl">Link del video *</label><input id="videoUrl" name="videoUrl" type="url" placeholder="https://youtu.be/..." required></div>`,
    social: `<div class="field"><label for="socialUrl">Link al profilo o alla pagina *</label><input id="socialUrl" name="socialUrl" type="url" placeholder="https://www.instagram.com/..." required></div>`
  };
  let currentType = 'web', currentMatrix = null, currentPayload = '', logoImg = null, logoData = '', toastTimer;
  const get = (name) => (document.querySelector(`#qrForm [name="${name}"]`)?.value || '').trim();
  const error = (msg) => { $('formError').textContent = msg; throw new Error(msg); };
  function validUrl(v) {
    if (!v) error('Inserisci un indirizzo web.');
    let s = v;
    if (/^www\./i.test(s) || /^[\w-]+\.[a-z]{2,}(\/|$)/i.test(s)) s = 'https://' + s;
    try { const u = new URL(s); if (!['https:','http:'].includes(u.protocol) || !u.hostname || !u.hostname.includes('.')) throw Error(); return u.href; }
    catch { error('Inserisci un indirizzo valido che inizi con https:// o http://.'); }
  }
  function validateMail(mail) {if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) error('Inserisci un indirizzo email valido.');return mail;}
  const vEscape = (value) => value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
  const wifiEscape = (value) => value.replace(/[\\;,:"]/g, (m)=>'\\'+m);
  function dateLocal(v){return v.replace(/[-:]/g,'').replace('T','T')+'00';}
  function buildPayload() {
    switch(currentType){
      case 'web':return validUrl(get('url'));
      case 'text': {const v = get('message'); if(!v) error('Scrivi il testo da trasformare in QR.');return v;}
      case 'email': {const mail = validateMail(get('to')); const query = new URLSearchParams();if(get('subject')) query.set('subject',get('subject'));if(get('body')) query.set('body',get('body'));return 'mailto:'+mail+(query.toString()?'?'+query.toString():'');}
      case 'photo':return validUrl(get('photoUrl'));
      case 'pdf':return validUrl(get('pdfUrl'));
      case 'video':return validUrl(get('videoUrl'));
      case 'social':return validUrl(get('socialUrl'));
      case 'wifi': {const ssid=get('ssid'); if(!ssid) error('Inserisci il nome della rete Wi-Fi.');const sec=get('security'); const pwd=document.querySelector('#password')?.value || '';if(sec!=='nopass' && !pwd) error('Inserisci la password oppure scegli «Rete aperta».');return `WIFI:T:${sec};S:${wifiEscape(ssid)};${sec==='nopass'?'':`P:${wifiEscape(pwd)};`}H:${$('hidden').checked?'true':'false'};;`;}
      case 'contact':{const first=get('first'),last=get('last');if(!first) error('Inserisci il nome del contatto.');if(!get('contactTel')&&!get('contactMail')&&!get('contactWeb')) error('Aggiungi almeno un recapito: telefono, email o sito.');if(get('contactMail')) validateMail(get('contactMail'));const url=get('contactWeb')?validUrl(get('contactWeb')):'';const arr=['BEGIN:VCARD','VERSION:3.0',`N:${vEscape(last)};${vEscape(first)};;;`,`FN:${vEscape((first+' '+last).trim())}`];if(get('org'))arr.push(`ORG:${vEscape(get('org'))}`);if(get('contactTel'))arr.push(`TEL:${vEscape(get('contactTel'))}`);if(get('contactMail'))arr.push(`EMAIL:${get('contactMail')}`);if(url)arr.push(`URL:${url}`);arr.push('END:VCARD');return arr.join('\r\n');}
      case 'phone':{const v=get('phone');if(!/^[+\d ()-]{5,30}$/.test(v))error('Inserisci un numero telefonico valido.');return 'tel:'+v.replace(/[ ()-]/g,'');}
      case 'sms':{const v=get('smsTo');if(!/^[+\d ()-]{5,30}$/.test(v))error('Inserisci un numero per l’SMS.');return `SMSTO:${v.replace(/[ ()-]/g,'')}:${get('smsBody')}`;}
      case 'whatsapp':{const d=get('waTo').replace(/[\s()+-]/g,'');if(!/^\d{8,16}$/.test(d))error('Inserisci il numero con prefisso internazionale, solo cifre.');const msg=get('waText');return `https://wa.me/${d}${msg?'?text='+encodeURIComponent(msg):''}`;}
      case 'event':{const title=get('eventName'),start=get('start'),end=get('end');if(!title||!start||!end)error('Compila titolo, inizio e fine evento.');if(new Date(end)<=new Date(start))error('La fine dell’evento deve essere successiva all’inizio.');const params=new URLSearchParams({action:'TEMPLATE',text:title,dates:`${dateLocal(start)}/${dateLocal(end)}`});if(get('eventPlace'))params.set('location',get('eventPlace'));if(get('details'))params.set('details',get('details'));return `https://calendar.google.com/calendar/render?${params.toString()}`;}
      case 'location':{const q=get('place');if(!q)error('Inserisci un luogo o un indirizzo.');return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(q)}`;}
      default:error('Scegli una categoria valida.');
    }
  }
  function updateType(id){
    currentType=id;const item=types.find(x=>x.id===id);
    $('typeMenu').querySelectorAll('.type-button').forEach(b=>{let active=b.dataset.type===id;b.classList.toggle('active',active);b.setAttribute('aria-current',active?'true':'false');});
    $('activeIcon').textContent=item.icon;$('activeName').textContent=item.name;$('activeDescription').textContent=item.desc;$('contextTip').textContent=item.tip;
    $('dynamicFields').innerHTML=fields[id];$('formError').textContent='';resetQR();
    $('menuToggle').setAttribute('aria-expanded','false');document.querySelector('.sidebar').classList.remove('open');
    $('dynamicFields').querySelector('input,textarea,select')?.focus({preventScroll:true});
  }
  function resetQR(){currentMatrix=null;currentPayload='';$('qrCanvas').style.display='none';$('placeholder').style.display='flex';$('pngBtn').disabled=true;$('svgBtn').disabled=true;$('copyBtn').disabled=true;$('printBtn').disabled=true;$('copyImageBtn').disabled=true;$('shareBtn').disabled=true;$('qrState').innerHTML='<span class="state-dot"></span> In attesa del tuo QR';}
  function showToast(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.remove('show'),3100);}
  function colorLum(hex){const rgb=[1,3,5].map(i=>parseInt(hex.slice(i,i+2),16)/255).map(x=>x<=.04045?x/12.92:Math.pow((x+.055)/1.055,2.4));return .2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2];}
  function isFinder(r,c,n){return (r<8&&c<8)||(r<8&&c>=n-8)||(r>=n-8&&c<8);}
  function settings(){return {fg:$('fgColor').value,bg:$('bgColor').value,shape:$('qrShape').value,size:+$('qrSize').value,margin:+$('qrMargin').value};}
  function drawRound(ctx,x,y,w,h,r){const rr=Math.min(r,w/2,h/2);ctx.beginPath();ctx.roundRect(x,y,w,h,rr);ctx.fill();}
  function drawQR(){
    if(!currentMatrix)return;const c=$('qrCanvas'),s=settings(),ctx=c.getContext('2d');
    c.width=c.height=s.size;const n=currentMatrix.size,unit=s.size/(n+2*s.margin),off=s.margin*unit;
    ctx.fillStyle=s.bg;ctx.fillRect(0,0,s.size,s.size);ctx.fillStyle=s.fg;
    for(let r=0;r<n;r++)for(let col=0;col<n;col++)if(currentMatrix.isDark(r,col)){
      const x=off+col*unit,y=off+r*unit,shape=isFinder(r,col,n)?'square':s.shape;
      if(shape==='dots'){ctx.beginPath();ctx.arc(x+unit/2,y+unit/2,unit*.425,0,Math.PI*2);ctx.fill();}
      else if(shape==='rounded')drawRound(ctx,x+.035*unit,y+.035*unit,.93*unit,.93*unit,.24*unit);
      else ctx.fillRect(x,y,unit+.04,unit+.04);
    }
    if(logoImg){const side=s.size*.205,pad=s.size*.018,px=(s.size-side)/2,py=px;ctx.fillStyle=s.bg;drawRound(ctx,px-pad,py-pad,side+2*pad,side+2*pad,pad*1.25);const scale=Math.min(side/logoImg.width,side/logoImg.height);const w=logoImg.width*scale,h=logoImg.height*scale;ctx.drawImage(logoImg,(s.size-w)/2,(s.size-h)/2,w,h);}
    c.style.display='block';$('placeholder').style.display='none';
    const contrast=(Math.max(colorLum(s.fg),colorLum(s.bg))+.05)/(Math.min(colorLum(s.fg),colorLum(s.bg))+.05);
    $('colorWarning').classList.toggle('warning',contrast<4.5);$('colorWarning').textContent=contrast<4.5?'Attenzione: i colori sono poco contrastati. Un lettore potrebbe non riconoscere questo QR.':'Mantieni un buon contrasto e prova sempre il QR con la fotocamera.';
  }
  function generate(){
    $('formError').textContent='';
    try{const payload=buildPayload(), correction=logoImg?'H':$('qrCorrection').value;const matrix=window.FrancoQR(payload,correction);currentMatrix=matrix;currentPayload=payload;drawQR();$('pngBtn').disabled=false;$('svgBtn').disabled=false;$('copyBtn').disabled=false;$('printBtn').disabled=false;$('copyImageBtn').disabled=false;$('shareBtn').disabled=false;$('qrState').innerHTML='<span class="state-dot"></span> QR pronto: scaricalo, stampalo o condividilo';showToast('QR code pronto! Puoi scaricarlo.');}
    catch(e){$('formError').textContent=e.message?.includes('code length')||e.message?.includes('overflow')?'Contenuto troppo lungo per un QR leggibile. Usa un link più corto.':(e.message||'Controlla i dati inseriti.');}
  }
  function escAttr(v){return String(v).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');}
  function svgQR(){
    const s=settings(),n=currentMatrix.size,u=s.size/(n+2*s.margin),off=s.margin*u;let parts=[`<svg xmlns="http://www.w3.org/2000/svg" width="${s.size}" height="${s.size}" viewBox="0 0 ${s.size} ${s.size}"><rect width="100%" height="100%" fill="${s.bg}"/>`,`<g fill="${s.fg}">`];
    for(let r=0;r<n;r++)for(let c=0;c<n;c++)if(currentMatrix.isDark(r,c)){
      let x=off+c*u,y=off+r*u,shape=isFinder(r,c,n)?'square':s.shape;
      if(shape==='dots')parts.push(`<circle cx="${(x+u/2).toFixed(3)}" cy="${(y+u/2).toFixed(3)}" r="${(u*.425).toFixed(3)}"/>`);
      else if(shape==='rounded')parts.push(`<rect x="${(x+.035*u).toFixed(3)}" y="${(y+.035*u).toFixed(3)}" width="${(.93*u).toFixed(3)}" height="${(.93*u).toFixed(3)}" rx="${(.24*u).toFixed(3)}"/>`);
      else parts.push(`<rect x="${x.toFixed(3)}" y="${y.toFixed(3)}" width="${(u+.04).toFixed(3)}" height="${(u+.04).toFixed(3)}"/>`);
    }
    parts.push('</g>');if(logoData&&logoImg){const side=s.size*.205,pad=s.size*.018,x=(s.size-side)/2,y=x;parts.push(`<rect x="${x-pad}" y="${y-pad}" width="${side+2*pad}" height="${side+2*pad}" rx="${pad*1.25}" fill="${s.bg}"/>`);const scale=Math.min(side/logoImg.width,side/logoImg.height),w=logoImg.width*scale,h=logoImg.height*scale;parts.push(`<image href="${escAttr(logoData)}" x="${(s.size-w)/2}" y="${(s.size-h)/2}" width="${w}" height="${h}"/>`);}parts.push('</svg>');return parts.join('');
  }
  function downloadBlob(blob,name){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);}
  const filename=(ext)=>`franco-qr-${currentType}-${new Date().toISOString().slice(0,10)}.${ext}`;
  function setup(){
    types.forEach(t=>{const btn=document.createElement('button');btn.type='button';btn.className='type-button';btn.dataset.type=t.id;btn.innerHTML=`<span aria-hidden="true">${t.icon}</span>${t.name}`;btn.addEventListener('click',()=>updateType(t.id));$('typeMenu').appendChild(btn);});
    $('year').textContent=new Date().getFullYear();updateType('web');
    $('qrForm').addEventListener('submit',e=>{e.preventDefault();generate();});
    $('dynamicFields').addEventListener('click',e=>{
      const target=e.target.closest('button[data-link-field]');
      if(!target)return;
      const field=document.getElementById(target.dataset.linkField);
      if(!field)return;
      try{const url=new URL(field.value.trim());if(!['https:','http:'].includes(url.protocol))throw new Error();window.open(url.href,'_blank','noopener,noreferrer');}
      catch{ $('formError').textContent='Inserisci prima un link valido che inizi con https:// o http://.'; }
    });

    ['fgColor','bgColor','qrShape','qrSize','qrCorrection','qrMargin'].forEach(id=>$(id).addEventListener('change',()=>{if(currentMatrix){if(id==='qrCorrection')generate();else drawQR();}}));
    $('pngBtn').addEventListener('click',()=>{if(!currentMatrix)return;$('qrCanvas').toBlob(blob=>{if(blob)downloadBlob(blob,filename('png'));else showToast('Errore durante il download PNG.');},'image/png');});
    $('svgBtn').addEventListener('click',()=>{if(currentMatrix)downloadBlob(new Blob([svgQR()],{type:'image/svg+xml;charset=utf-8'}),filename('svg'));});
    $('printBtn').addEventListener('click',async()=>{
      if(!currentMatrix)return;
      const image=$('printImage');image.src=$('qrCanvas').toDataURL('image/png');
      $('printCaption').textContent=['web','photo','pdf','video','social'].includes(currentType)?currentPayload:'';
      try{await image.decode();}catch{}
      window.print();
    });
    $('copyImageBtn').addEventListener('click', async()=>{
      if(!currentMatrix)return;
      try{
        if(!window.ClipboardItem||!navigator.clipboard?.write)throw new Error('Non disponibile');
        const blob=await new Promise((resolve,reject)=>$('qrCanvas').toBlob(b=>b?resolve(b):reject(new Error('Esportazione fallita')),'image/png'));
        await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);showToast('Immagine QR copiata negli appunti.');
      }catch{showToast('Copia immagine non disponibile qui: usa Scarica QR.');}
    });
    $('shareBtn').addEventListener('click',async()=>{
      if(!currentMatrix)return;
      try{
        if(!navigator.share)throw new Error('condivisione non supportata');
        await navigator.share({title:'Franco QR Studio',text:'Ecco il contenuto del mio QR code',url:/^https?:\/\//.test(currentPayload)?currentPayload:undefined});
      }catch(err){if(err.name!=='AbortError')showToast('Condivisione non disponibile: usa Scarica QR.');}
    });
    document.querySelectorAll('[data-preset]').forEach(button=>button.addEventListener('click',()=>{
      const styles={classic:['#111827','#ffffff'],navy:['#173a7c','#ffffff'],forest:['#075d53','#ffffff'],violet:['#673ab7','#ffffff']};
      const [fg,bg]=styles[button.dataset.preset];$('fgColor').value=fg;$('bgColor').value=bg;
      if(currentMatrix)drawQR();showToast('Stile applicato.');
    }));

    $('copyBtn').addEventListener('click',async()=>{if(!currentPayload)return;try{await navigator.clipboard.writeText(currentPayload);showToast('Contenuto copiato.');}catch{const temp=document.createElement('textarea');temp.value=currentPayload;document.body.appendChild(temp);temp.select();let ok=document.execCommand('copy');temp.remove();showToast(ok?'Contenuto copiato.':'Il browser non permette la copia: usa il QR scaricato.');}});
    $('resetBtn').addEventListener('click',()=>{updateType(currentType);$('logoInput').value='';logoImg=null;logoData='';$('clearLogo').hidden=true;showToast('Pronto per un nuovo QR.');});
    $('logoInput').addEventListener('change',e=>{const f=e.target.files?.[0];if(!f)return;if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>3*1024*1024){e.target.value='';showToast('Usa un’immagine JPG, PNG o WebP inferiore a 3 MB.');return;}const reader=new FileReader();reader.onload=()=>{const image=new Image();image.onload=()=>{logoImg=image;logoData=reader.result;$('clearLogo').hidden=false;if(currentMatrix)generate();};image.onerror=()=>showToast('Impossibile leggere l’immagine.');image.src=reader.result;};reader.readAsDataURL(f);});
    $('clearLogo').addEventListener('click',()=>{$('logoInput').value='';logoImg=null;logoData='';$('clearLogo').hidden=true;if(currentMatrix)generate();});
    $('menuToggle').addEventListener('click',()=>{const side=document.querySelector('.sidebar');side.classList.toggle('open');$('menuToggle').setAttribute('aria-expanded',side.classList.contains('open')?'true':'false');});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'){document.querySelector('.sidebar').classList.remove('open');$('menuToggle').setAttribute('aria-expanded','false');}});
  }
  document.addEventListener('DOMContentLoaded',setup);
})();
